window.onerror = (e) => {
	log('Error: ' + e);
};
const img = document.getElementById('image');
const video = document.getElementById('video');
const container = document.getElementById('container');
const preloader = document.getElementById('preloader');
const button = document.getElementById('button');

var app = {
	// Application Constructor
	initialize: function () {
		this.bindEvents();
	},
	// Bind Event Listeners
	//
	// Bind any events that are required on startup. Common events are:
	// 'load', 'deviceready', 'offline', and 'online'.
	bindEvents: function () {
		document.addEventListener('deviceready', this.onDeviceReady, false);
	},
	// deviceready Event Handler
	//
	// The scope of 'this' is the event. In order to call the 'receivedEvent'
	// function, we must explicitly call 'app.receivedEvent(...);'
	onDeviceReady: function () {
		app.receivedEvent('deviceready');
	},
	// Update DOM on a Received Event
	receivedEvent: function (id) {
		log('Android ready!');
		camera();
	}
};

function camera() {
	setTimeout(() => {
		log('Camera...');
		navigator.mediaDevices.getUserMedia({
				video: {facingMode: { exact: 'environment' }},
				audio: false
			})
			.then(function (stream) {
				window.stream = stream;
				video.srcObject = stream;
				video.play();
			})
			.catch(function (err) {
				log('An error occurred: ' + err);
			});
	}, 3000);
}
button.addEventListener('click', () => {
	log('Play')
	video.play();
});

let TFmodel = null;
preloader.innerHTML = 'Готовим модель (ждем...)!';
log(cocoSsd);
cocoSsd.load().then(model => {
	log('NN Ready!');
	preloader.innerHTML = 'Нейросеть готова!';
	TFmodel = model;
	setInterval(() => {
		clearBorders();
		TFmodel.detect(video).then(predictions => {
			preloader.innerHTML = 'Обьектов: ' + predictions.length;
			predictions.forEach(p => {
				// log('Find: '+p.class);
				const el = document.createElement('div');
				el.classList.add('border');
				container.appendChild(el);
				const pos = p.bbox;
				el.style.width = pos[2] + 'px';
				el.style.height = pos[3] + 'px';
				el.style.left = pos[0] + 'px';
				el.style.top = pos[1] + 'px';
				el.innerHTML = '<div class="title">' + p.class + '</div>';
			});
		});
	}, 100);
}).catch(err => log('Catch: ' + err));

function clearBorders() {
	document.querySelectorAll('.border').forEach(el => el.parentNode.removeChild(el));
}

function log(str) {
	console.log(str);
	if (typeof str === 'object') {
		str = JSON.stringify(str);
	}
	const p = document.createElement('p');
	p.innerHTML = str;
	document.getElementById('log').appendChild(p);
}